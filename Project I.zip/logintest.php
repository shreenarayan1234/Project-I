<?php

if(isset($_POST['sl'])){
    echo 'student has logged in';
}

if(isset($_POST['al'])){
    echo 'admin has logged in';
}else{
    // echo "hi";
}